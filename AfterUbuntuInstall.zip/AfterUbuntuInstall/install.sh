#!/bin/bash

echo "Setting up repos..."
bash repos.sh

echo "Installing packages..."
while read -r pkg; do
  sudo apt install -y "$pkg" || echo "Failed: $pkg"
done < Software_file.txt